(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8.css","static/chunks/node_modules__pnpm_12mm8q8._.js","static/chunks/app_components_1p63lkk._.js"],
    source: "dynamic"
});
