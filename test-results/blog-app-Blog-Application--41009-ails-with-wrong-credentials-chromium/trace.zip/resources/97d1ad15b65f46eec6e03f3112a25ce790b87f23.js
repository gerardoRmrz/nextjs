(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1rnw8-w._.js","static/chunks/1hr2_next_dist_compiled_next-devtools_index_1q2fpe6.js","static/chunks/1hr2_next_dist_compiled_react-dom_1f--2ag._.js","static/chunks/1hr2_next_dist_compiled_react-server-dom-turbopack_03uyb1f._.js","static/chunks/1hr2_next_dist_compiled_1n7in5w._.js","static/chunks/1hr2_next_dist_client_0_uod33._.js","static/chunks/1hr2_next_dist_1k0z6zj._.js","static/chunks/0vvp_@swc_helpers_cjs_0vb02wp._.js"],
    source: "entry"
});
